# Abstração de Projeto

Este documento define uma camada de abstração do projeto voltada a humanos e agentes que precisam entender o sistema sem depender primeiro da stack, da estrutura de pastas ou da implementação atual.

O objetivo é responder com clareza:

- qual problema o projeto se propõe a resolver;
- para quem ele existe;
- quais capacidades entrega;
- quais entradas consome;
- quais saídas produz;
- quais limites, riscos e invariantes precisam ser preservados.

## 1. Papel desta camada

Essa camada existe para evitar que a leitura do projeto comece pela tecnologia em vez do domínio.

Ela ajuda especialmente quando:

- um agente novo entra no repositório sem contexto prévio;
- o projeto já passou por mais de uma stack ou está em transição;
- a implementação atual não expressa com clareza a intenção do produto;
- diferentes superfícies, como UI, API, jobs ou automações, participam da mesma solução.

## 2. O que esta documentação deve explicar

Uma boa abstração de projeto deve tornar explícito:

- a dor, necessidade ou processo que o projeto organiza;
- o resultado que o usuário espera obter;
- as entidades principais do domínio;
- o ciclo básico de entrada, transformação e saída;
- o que é essencial continuar verdadeiro mesmo se a stack mudar.

Perguntas que essa doc deve conseguir responder:

- o que este projeto resolve;
- o que ele faz na prática;
- quem usa ou depende dele;
- quais decisões o sistema precisa apoiar;
- quais artefatos, respostas ou efeitos ele entrega;
- o que seria uma regressão conceitual, mesmo que o código compile.

## 3. O que esta documentação não deve virar

Esta doc não substitui:

- `README.md`, que continua explicando estado atual e forma de uso;
- `docs/arquitetura.md`, que descreve a implementação real;
- `AGENTS.md`, que define a operação dos agentes;
- documentação de API, UI, deploy ou runbooks específicos.

Também não deve virar:

- inventário de framework;
- lista de bibliotecas;
- espelho de árvore de arquivos;
- texto aspiracional desconectado do produto real.

## 4. Estrutura recomendada

Estrutura mínima sugerida para `docs/abstracao-projeto.md`:

1. problema central que o projeto resolve;
2. usuário, operador ou sistema beneficiado;
3. resultado esperado;
4. capacidades principais;
5. entidades e conceitos do domínio;
6. fluxo conceitual de entrada, processamento e saída;
7. limites, exclusões e não objetivos;
8. invariantes do projeto;
9. critérios de sucesso e sinais de regressão conceitual.

## 5. Relação com agentes

Para agentes, essa doc funciona como um mapa de intenção do projeto.

Ela reduz erros como:

- assumir que a stack atual define o produto;
- tratar detalhe de implementação como regra de negócio;
- preservar acidentalmente um legado técnico que já não representa a necessidade real;
- propor mudanças coerentes com o código, mas incoerentes com o propósito do sistema.

## 6. Template mínimo

```text
# Abstração do Projeto

## 1. Problema que o projeto resolve

## 2. Para quem este projeto existe

## 3. Resultado esperado

## 4. Capacidades principais

## 5. Conceitos e entidades do domínio

## 6. Fluxo conceitual

- entrada
- transformação
- saída

## 7. O que este projeto não pretende resolver

## 8. Invariantes

## 9. Sinais de sucesso e sinais de regressão conceitual
```

## 7. Regra de adoção em outros projetos

Quando a pasta `vogel-stack/` for copiada para outro repositório como base documental, a recomendação é adicionar `vogel-stack/` ao `.gitignore` do projeto de destino.

Isso evita tratar a stack documental compartilhada como parte do produto daquele repositório quando ela estiver sendo usada apenas como suporte operacional local.

Exceção explícita:

- neste repositório de desenvolvimento do `Vogel Stack`, a pasta `vogel-stack/` não deve ser ignorada, porque ela é o próprio conteúdo-fonte mantido em versão.
