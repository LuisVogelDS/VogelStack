# Vogel Stack

`Vogel Stack` é um conjunto de documentos-base para repositórios que usam agentes de IA como parte real do fluxo de desenvolvimento, documentação e operação.

O objetivo desta pasta é transformar práticas testadas em um projeto específico em um padrão reutilizável para outros contextos, sem depender de regras subjetivas ou conhecimento tribal.

## Propósito

Esta stack ajuda a manter:

- documentação coerente com o código real;
- regras operacionais claras para agentes e humanos;
- matriz explícita do que é suportado, experimental ou apenas legado;
- contratos de entrada e saída mais estáveis para UI, API e automações;
- evolução arquitetural controlada;
- versionamento e changelog auditáveis;
- critérios mais objetivos para mudanças de produto e dashboard;
- guardrails para custo, execução e observabilidade;
- economia de créditos via handoff de execuções caras com scripts e logs persistentes.

## Estrutura

- `abstracao-projeto.md`: define a camada de abstração do projeto focada em problema, propósito, capacidades e invariantes, sem depender da stack.
- `principios.md`: princípios permanentes para qualquer projeto.
- `operacao-agentes.md`: política operacional para uso de agentes, comandos e execuções.
- `registro-e-evidencias.md`: padrão para registry, manifestos e rastreabilidade de execuções.
- `documentacao-e-versionamento.md`: papéis dos docs, regras de atualização e convenções de versionamento.
- `evolucao-produto.md`: método para evoluir arquitetura, produto e dashboards sem ficar preso ao legado atual.
- `templates.md`: modelos de documentos para iniciar novos repositórios com o mesmo padrão.

## Como usar

Forma mínima de adoção em outro projeto:

1. copiar esta pasta para o novo repositório;
2. adicionar `vogel-stack/` ao `.gitignore` do projeto de destino quando essa pasta estiver sendo usada como base de apoio e não como conteúdo-fonte do produto;
3. adaptar `templates.md` para gerar `AGENTS.md`, `README.md`, `docs/abstracao-projeto.md`, `docs/arquitetura.md`, `docs/versionamento.md` e `docs/changelog.md`;
4. preencher `docs/abstracao-projeto.md` antes de detalhar stack, para que humanos e agentes entendam o que o projeto resolve e o que ele entrega;
5. ajustar fontes de verdade, fluxo de deploy, autenticação, matriz de suporte de ambiente e contratos do projeto alvo;
6. manter os documentos atualizados no mesmo ciclo em que o comportamento do produto mudar.

Exceção:

- neste repositório de desenvolvimento do `Vogel Stack`, a pasta `vogel-stack/` não deve entrar no `.gitignore`, porque ela é a própria base versionada desta stack.

## Escopo

Esta stack não tenta impor uma linguagem, framework ou arquitetura única.

Ela define:

- abstração de projeto orientada a problema, propósito e capacidades;
- critérios de clareza;
- disciplina de documentação;
- padrão operacional de agentes;
- padrão de evidência operacional e rastreabilidade de runs;
- disciplina de contratos, schemas e identificadores canônicos;
- método de evolução de produto;
- guardrails para evitar desperdício, opacidade e retrabalho.
